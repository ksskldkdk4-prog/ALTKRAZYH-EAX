package com.altkrazyh.eax

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private val engine = AudioEngine()
    private lateinit var status: TextView
    private lateinit var start: Button
    private lateinit var stop: Button
    private val bg = Color.rgb(10, 20, 34)
    private val card = Color.rgb(23, 39, 57)
    private val blue = Color.rgb(15, 125, 205)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 24, 18, 28); setBackgroundColor(bg) }
        scroll.addView(page); setContentView(scroll)
        page.addView(label("ALTKRAZYH EAX", 27, Color.WHITE, true))
        page.addView(label("REAL-TIME VOICE EFFECTS  •  ANDROID", 12, Color.rgb(68,190,230), true))
        page.addView(panelTitle("MICROPHONE CONTROL"))
        status = label("الحالة: متوقف", 14, Color.YELLOW, true); page.addView(status)
        start = button("🎙  START MICROPHONE"); page.addView(start)
        stop = button("■  STOP"); stop.isEnabled = false; page.addView(stop)
        page.addView(label("استخدم سماعة لتجنب رجوع الصوت إلى الميكروفون.", 12, Color.LTGRAY, false))
        page.addView(panelTitle("VOICE MASKS"))
        val masks = listOf("Normal", "Deep", "Robot", "Alien", "Monster", "Telephone", "Chipmunk", "Radio")
        page.addView(choiceGrid(masks) { engine.preset = it })
        page.addView(panelTitle("EAX ENVIRONMENTS"))
        val rooms = listOf("Normal", "Cathedral", "Haunted Cave", "Chapel", "Concert Hall", "Tunnel", "Bathroom")
        page.addView(choiceGrid(rooms) { engine.room = it })
        page.addView(panelTitle("AUDIO CONTROL"))
        page.addView(slider("Microphone / Input", 0, 150, 100) { engine.inputLevel = it / 100f })
        page.addView(slider("Master / Output", 0, 150, 80) { engine.outputLevel = it / 100f })
        page.addView(slider("Effects Amount", 0, 100, 50) { engine.effectAmount = it / 100f })
        page.addView(label("ملاحظة: المؤثرات تعمل داخل التطبيق ويخرج الصوت عبر سماعة الهاتف أو السماعة المتصلة. لا يستطيع هذا التطبيق العادي استبدال ميكروفون PUBG أو المكالمات الأخرى على مستوى النظام.", 12, Color.rgb(255,195,125), false))
        page.addView(label("ALTKRAZYH EAX • Version 1.0", 11, Color.GRAY, false))
        start.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 40)
            } else startAudio()
        }
        stop.setOnClickListener { engine.stop(); status.text = "الحالة: متوقف"; start.isEnabled = true; stop.isEnabled = false }
    }

    private fun startAudio() {
        try { engine.start(); status.text = "● المايكروفون يعمل"; status.setTextColor(Color.GREEN); start.isEnabled = false; stop.isEnabled = true }
        catch (e: Exception) { status.text = "تعذر التشغيل: ${e.message}" }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 40 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startAudio()
        else status.text = "يجب السماح باستخدام الميكروفون."
    }
    override fun onDestroy() { engine.stop(); super.onDestroy() }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(4, 8, 4, 8) }
    private fun panelTitle(text: String): TextView = label(text, 15, Color.rgb(100,190,245), true).apply {
        setPadding(12, 18, 8, 8)
    }
    private fun button(text: String): Button = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); setBackgroundColor(blue); isAllCaps = false
    }
    private fun choiceGrid(items: List<String>, choose: (String) -> Unit): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8); setBackgroundColor(card) }
        items.chunked(2).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { item ->
                val b = Button(this).apply { text = item; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(37,61,84)) }
                b.setOnClickListener { choose(item); Toast.makeText(this, "$item selected", Toast.LENGTH_SHORT).show() }
                row.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(4,4,4,4) })
            }
            wrap.addView(row)
        }
        return wrap
    }
    private fun slider(title: String, min: Int, max: Int, initial: Int, changed: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10,8,10,8); setBackgroundColor(card) }
        val name = label("$title: $initial%", 13, Color.WHITE, false); box.addView(name)
        val seek = SeekBar(this).apply { this.max = max-min; progress = initial-min }
        seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { val v=p+min; name.text="$title: $v%"; changed(v) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        box.addView(seek); return box
    }
}
