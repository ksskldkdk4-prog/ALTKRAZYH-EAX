package com.altkrazyh.eax

import android.media.*
import android.os.Process
import kotlin.math.*

class AudioEngine {
    @Volatile var running = false
    @Volatile var preset = "Normal"
    @Volatile var room = "Normal"
    @Volatile var inputLevel = 1.0f
    @Volatile var outputLevel = 0.8f
    @Volatile var effectAmount = 0.5f
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var worker: Thread? = null
    private val rate = 44100
    private var delayL = FloatArray(rate)
    private var delayPos = 0
    private var lp = 0f
    private var hpPrevIn = 0f
    private var hpPrevOut = 0f
    private var phase = 0.0

    fun start() {
        if (running) return
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) throw IllegalStateException("Audio device unavailable")
        val bufferSize = max(minIn, 4096)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(minOut, 4096))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        if (rec.state != AudioRecord.STATE_INITIALIZED || track.state != AudioTrack.STATE_INITIALIZED) {
            rec.release(); track.release(); throw IllegalStateException("Microphone/audio output could not initialize")
        }
        recorder = rec; player = track
        rec.startRecording(); track.play(); running = true
        worker = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val input = ShortArray(1024)
            val output = ShortArray(1024)
            while (running) {
                val n = try { rec.read(input, 0, input.size) } catch (_: Exception) { -1 }
                if (n <= 0) continue
                for (i in 0 until n) {
                    var x = input[i] / 32768f * inputLevel
                    x = process(x)
                    x *= outputLevel
                    output[i] = (x.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                }
                try { track.write(output, 0, n) } catch (_: Exception) { }
            }
        }.also { it.start() }
    }

    private fun process(input: Float): Float {
        var x = input
        when (preset) {
            "Robot" -> { phase += 2.0 * PI * 35.0 / rate; x *= sin(phase).toFloat() * 0.65f + 0.35f }
            "Alien" -> { phase += 2.0 * PI * 8.0 / rate; x *= (0.55f + 0.45f * sin(phase).toFloat()) }
            "Monster" -> { x = (x * 4.2f).coerceIn(-1f, 1f); x = (tanh(x * 2.4f) / tanh(2.4f)).toFloat() }
            "Telephone" -> { lp += 0.18f * (x - lp); x = lp; x = x - hpPrevIn + 0.94f * hpPrevOut; hpPrevIn = lp; hpPrevOut = x }
            "Deep" -> { lp += 0.12f * (x - lp); x = x * 0.65f + lp * 1.5f }
            "Chipmunk" -> { x = (x * 1.5f).coerceIn(-1f, 1f); x = tanh(x * 1.5f).toFloat() }
            "Radio" -> { lp += 0.28f * (x - lp); x = (x - lp) * 1.5f }
        }
        val roomMix = when (room) {
            "Cathedral" -> 0.68f
            "Haunted Cave" -> 0.78f
            "Chapel" -> 0.45f
            "Concert Hall" -> 0.58f
            "Tunnel" -> 0.52f
            "Bathroom" -> 0.38f
            else -> 0f
        } * effectAmount
        val delayed = delayL[delayPos]
        delayL[delayPos] = (x + delayed * 0.48f).coerceIn(-1f, 1f)
        delayPos = (delayPos + 1) % delayL.size
        return x * (1f - roomMix * 0.45f) + delayed * roomMix
    }

    fun stop() {
        running = false
        try { worker?.join(500) } catch (_: Exception) {}
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        recorder?.release(); player?.release()
        recorder = null; player = null; worker = null
    }
}
